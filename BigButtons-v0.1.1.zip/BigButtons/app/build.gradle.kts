plugins {
    id("com.android.application")
}

android {
    namespace = "com.bigbuttons.remote"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.bigbuttons.remote"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
